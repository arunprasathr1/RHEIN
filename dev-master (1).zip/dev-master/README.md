# e2eIntUi

JavaScript Code written in Node/Express and React.
Uses multiple SCP services like XSUAA, Destination, Connectivity & HAAS.

Runs on Node.
