import AppLayout from "./AppLayout";

export default AppLayout;
